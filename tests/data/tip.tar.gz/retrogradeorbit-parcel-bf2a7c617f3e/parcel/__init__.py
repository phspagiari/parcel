__title__ = 'parcel'
__version__ = '0.1'
__author__ = 'Crispin Wellington'
__copyright__ = 'Copyright 2012 Crispin Wellington'

