"""Fake fabric stub, that actually puts mock objects everywhere so we can
check parcels objects without needing to call a remote host
"""
