import mock

#settings, run, cd, lcd, put, get, local, env, with_settings

settings = mock.MagicMock(name='settings')
run = mock.MagicMock(name='run')
cd = mock.MagicMock(name='cd')
lcd = mock.MagicMock(name='lcd')
put = mock.MagicMock(name='put')
get = mock.MagicMock(name='get')
local = mock.MagicMock(name='local')
env = mock.MagicMock(name='env')
with_settings = mock.MagicMock(name='with_settings')
